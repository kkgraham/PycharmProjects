# Krystal-Anne Graham

# room and directions dict
rooms = {
    'Great Hall':
        {'South': 'Bedroom'},
    'Bedroom':
        {'North': 'Great Hall', 'East': 'Cellar'},
    'Cellar':
        {'West': 'Bedroom'}
}
directions = ['North', 'South', 'East', 'West']

# defining variables
exit_command = "Exit"
valid_input = directions + [exit_command]
invalid_input = 'Hm, that did not work! Please try: '
cannot_go_that_way = 'Oops! You see no door this way!'
game_over = 'Game Over!'
exit_room_sentinel = 'exit'
error_statement = 'Uh oh, something went wrong!'
exit_phrase = "We hope you enjoyed Annie's Adventure! Come back soon!"

# Game Start Message
game_start = """\nWelcome to Annie's Adventure! Annie Lux is an elemental witch that uses her power to keep the 
   worlds elements in balance, holding sway over the elements of fire, air, water, earth, and spirit. One 
   day, an evil wizard comes to her temple and takes her magical items, leaving her and the land in 
   disarray and the elements out of balance. Help Annie navigate the cave she is in and leave without 
   getting lost!\n"""


def navigate(current_room: str, direction: str):
    global user_location
    user_location = rooms.get(user_location).get(user_move)
    return user_location, direction


# Initialize user location
user_location = 'Great Hall'

# Giving Game Description
print(game_start)

# defining stop condition and obtaining first result
user_move = input('You begin in the ' + user_location + '. Begin your adventure by entering a direction: ')

while True:

    # starting game and checking move for valid input
    if user_move in valid_input:

        # checking for exit command
        if user_move == 'Exit':
            user_location = 'Exit'
            print(exit_phrase)
            break

        elif user_move in directions:

            if user_move in rooms.get(user_location):
                # navigating rooms
                result = navigate(user_location, user_move)
                user_location = result[0]
                print('You are in the: ', user_location)
                user_move = input('Please enter a new direction: ')

            # checking for incorrect moves
            elif user_move not in rooms.get(user_location):
                print(cannot_go_that_way)
                print('You are in the: ', user_location)
                user_move = input('Please enter a new direction: ')

    # checking for invalid input
    elif user_move not in valid_input:
        print(invalid_input, valid_input)
        user_move = input('Please try again: ')

    # error statement if needed
    else:
        print(error_statement)
